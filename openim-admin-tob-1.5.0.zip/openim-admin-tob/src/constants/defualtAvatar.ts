import ic_avatar_01 from '@/assets/defualtAvatar/ic_avatar_01.png';
import ic_avatar_02 from '@/assets/defualtAvatar/ic_avatar_02.png';
import ic_avatar_03 from '@/assets/defualtAvatar/ic_avatar_03.png';
import ic_avatar_04 from '@/assets/defualtAvatar/ic_avatar_04.png';
import ic_avatar_05 from '@/assets/defualtAvatar/ic_avatar_05.png';
import ic_avatar_06 from '@/assets/defualtAvatar/ic_avatar_06.png';

export default {
  ic_avatar_01: ic_avatar_01,
  ic_avatar_02: ic_avatar_02,
  ic_avatar_03: ic_avatar_03,
  ic_avatar_04: ic_avatar_04,
  ic_avatar_05: ic_avatar_05,
  ic_avatar_06: ic_avatar_06,
};
