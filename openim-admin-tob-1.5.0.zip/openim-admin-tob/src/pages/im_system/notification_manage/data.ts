export interface NotificationAccount {
  userID: string;
  nickName: string;
  faceURL: string;
}
