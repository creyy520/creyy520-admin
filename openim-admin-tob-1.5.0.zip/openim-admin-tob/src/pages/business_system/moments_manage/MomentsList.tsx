const MomentsManage = () => {
  return <div>MomentsManage</div>;
};

export default MomentsManage;
