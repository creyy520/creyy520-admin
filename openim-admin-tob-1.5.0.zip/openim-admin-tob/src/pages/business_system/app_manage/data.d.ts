type applet = {
  appID: string;
  createTime: number;
  icon: string;
  id: string;
  md5: string;
  name: string;
  priority: number;
  size: number;
  status: number;
  url: string;
  version: string;
};
