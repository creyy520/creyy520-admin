const Moments = () => {
  return <div>b/s/m</div>;
};

export default Moments;
