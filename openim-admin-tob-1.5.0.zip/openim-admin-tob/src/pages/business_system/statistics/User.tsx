const User = () => {
  return <div>b/s/u</div>;
};

export default User;
