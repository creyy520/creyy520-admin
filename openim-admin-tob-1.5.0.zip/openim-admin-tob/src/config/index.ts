// ws 10001 api 10002 chat 10008 Admin 10009

export const WS_URL = 'wss://14.29.213.197:50001';
export const API_URL = 'http://14.29.213.197:50002';
export const CHAT_URL = 'http://14.29.213.197:60008';
export const ACCOUNT_URL = 'http://14.29.213.197:60009';

export const OBJECT_STORAGE = 'minio';
